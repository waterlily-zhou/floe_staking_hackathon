from setuptools import setup
setup(name='autonomy', version='0.12.7')